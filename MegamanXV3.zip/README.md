# Overview
Megaman X survivor for Risk Of Rain 2, time to hunt some maverick monsters!
This mod contais the classics SFX for shot and charge shot and voice for some skills!

# Instructions for install:
place the dll in your plugins folder or extract to a folder inside plugins.


# Screenshots
![](https://i.imgur.com/6wxbu0M.png)
![](https://i.imgur.com/e7Xdapm.png)
![](https://i.imgur.com/gtfzcpG.png)
![](https://i.imgur.com/pFeJtnX.png)

# Feedback
Hey, if you want to talk, give me a hint for this mod you can DM me on discord, but sorry for my bad english and this is my first mod i hope you enjoy   >.<

# Discord
BLKNeko#8448 (i'm also in the RoR2 modding community, they helped me a lot)

#KNOW ISSUES:
- Golden Needler is not working for no reason.
- FIXED - Jump animation on the survival select screen, again, i don't know how to fix sorry >.< - THANKS TO: Zerodomai Kitsune
- FIXED - On character select keep switching characters add a new "skin" tab, but the game work OK. - THANKS TO: Dragonyck and Rob


#Skins:
Sorry, i really tried but i can't make skins work properly.



# Changelog
V 3.0.0 Remake of the mod bacause it went broken after the void update, some effects now are visualy better, hope you enjoy!
V 2.1.2 Remake of the mod bacause it went deprecated, some effects now are visualy better, hope you enjoy!
V 2.1.1 Added Skins(please refear to Skins Section to know how to select them) and fixed the skin tab bug.
V 2.0.0 NEW X MODEL, added Acid Burst special skill, added new attack and charge animations, fix run and sprint animations, added a new passive skill, added some visual effects.
V 1.6.6 Added a simple charging visual effect
V 1.5.6 Added Fire Wave secondary skill
V 1.4.5 Added FK-Buster (Falcon Buster) primary skill, change basic shoot, fix some networking problems(sorry i forget to add some skill >.<), added Icons to new skills and rename some tokens for networking and compatibility.
V 1.2.4 Added Squeeze Bomb Secondary Skill
V 1.1.4 Added MeltCreeper Special Skill
V 1.0.4 Fixed Jump animation on survival select screen
V 1.0.3 Missing needed dependencies
V 1.0.0 Posted

# Special Thanks
- The RoR2 Modding Community
- My Friends
- My Family
- eXcella who send me the new models!!
- vegetableaux who show me how to add passive skills

# Donations
-Please, remember this mod is FREE and aways will be, i made this hoping that you would enjoy and have fun !
-If you want to support me this is the link
https://www.paypal.com/donate?hosted_button_id=JU57WD5QVUC2Y


#CREDITS
MEGAMAN X MODEL ORIGINAL CREDITS!!!
https://drive.google.com/drive/folders/1rg-ong734AY7Oo-N3EnK76pH-MCgakry
